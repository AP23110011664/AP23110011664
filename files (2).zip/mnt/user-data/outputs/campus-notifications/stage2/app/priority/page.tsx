"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Box,
  Container,
  Typography,
  Stack,
  Slider,
  Alert,
  Skeleton,
  Paper,
  Tooltip,
  IconButton,
  Button,
} from "@mui/material";
import StarIcon from "@mui/icons-material/Star";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import DoneAllIcon from "@mui/icons-material/DoneAll";
import Navbar from "@/components/Navbar";
import NotificationCard from "@/components/NotificationCard";
import {
  Notification,
  fetchNotifications,
  getTopN,
  markAllAsRead,
} from "@/lib/notifications";
import { getLogger } from "@/lib/logger";

const logger = getLogger("page.priority-inbox");

const TYPE_WEIGHT_LABEL: Record<string, string> = {
  Placement: "Weight 3 (Highest)",
  Result: "Weight 2",
  Event: "Weight 1",
};

export default function PriorityInboxPage() {
  const [allNotifications, setAllNotifications] = useState<Notification[]>([]);
  const [topN, setTopN] = useState<Notification[]>([]);
  const [n, setN] = useState(10);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadAndRank = useCallback(async () => {
    setLoading(true);
    setError(null);
    logger.info("Loading and ranking notifications for priority inbox", { n });
    try {
      // Fetch a large batch for ranking
      const data = await fetchNotifications({ limit: 100 });
      setAllNotifications(data);
      setTopN(getTopN(data, n));
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to load";
      logger.error("Failed to load notifications for priority inbox", { error: msg });
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, [n]);

  useEffect(() => {
    loadAndRank();
  }, [loadAndRank]);

  // Re-rank when n changes without re-fetching
  const handleNChange = (_: Event, val: number | number[]) => {
    const newN = val as number;
    logger.info("Priority inbox N changed", { newN });
    setN(newN);
    setTopN(getTopN(allNotifications, newN));
  };

  const unreadCount = topN.filter((n) => !n.isRead).length;

  const handleMarkAllRead = () => {
    markAllAsRead(topN.map((n) => n.id));
    setTopN((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const handleRead = (id: string) => {
    setTopN((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  };

  // Stats
  const typeStats = topN.reduce<Record<string, number>>((acc, n) => {
    acc[n.type] = (acc[n.type] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <Box sx={{ minHeight: "100vh", background: "#0a0e1a" }}>
      <Navbar unreadCount={unreadCount} onRefresh={loadAndRank} />

      <Container maxWidth="lg" sx={{ py: 4 }}>
        {/* Header */}
        <Box sx={{ mb: 4, display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 2 }}>
          <Box>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
              <StarIcon sx={{ color: "#ffd43b", fontSize: 32 }} />
              <Typography
                variant="h4"
                sx={{
                  fontWeight: 800,
                  background: "linear-gradient(135deg, #ffd43b, #f783ac)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                Priority Inbox
              </Typography>
              <Tooltip
                title="Priority = Type weight (Placement > Result > Event) + Recency. Maintained via O(log N) min-heap for efficient streaming updates."
                placement="right"
              >
                <IconButton size="small" sx={{ color: "text.disabled" }}>
                  <InfoOutlinedIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>
            <Typography variant="body2" color="text.secondary">
              Your most important notifications, intelligently ranked
            </Typography>
          </Box>

          {unreadCount > 0 && (
            <Button
              startIcon={<DoneAllIcon />}
              size="small"
              variant="outlined"
              onClick={handleMarkAllRead}
            >
              Mark all read
            </Button>
          )}
        </Box>

        {/* N Selector */}
        <Paper
          sx={{
            p: 3,
            mb: 4,
            background: "rgba(17,24,39,0.8)",
            border: "1px solid rgba(255,212,59,0.2)",
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 2, flexWrap: "wrap", gap: 1 }}>
            <Typography variant="body2" sx={{ fontWeight: 600, color: "text.secondary" }}>
              Showing top <span style={{ color: "#ffd43b", fontSize: "1.1em" }}>{n}</span> notifications
            </Typography>
            <Box sx={{ display: "flex", gap: 2 }}>
              {Object.entries(typeStats).map(([type, count]) => (
                <Typography key={type} variant="caption" sx={{ color: "text.disabled" }}>
                  {type}: {count}
                </Typography>
              ))}
            </Box>
          </Box>
          <Slider
            value={n}
            min={5}
            max={20}
            step={5}
            marks={[
              { value: 5, label: "5" },
              { value: 10, label: "10" },
              { value: 15, label: "15" },
              { value: 20, label: "20" },
            ]}
            onChange={handleNChange}
            valueLabelDisplay="auto"
            sx={{
              color: "#ffd43b",
              "& .MuiSlider-rail": { background: "rgba(255,212,59,0.2)" },
              "& .MuiSlider-markLabel": { color: "text.secondary", fontSize: "0.7rem" },
            }}
          />

          {/* Legend */}
          <Box sx={{ display: "flex", gap: 3, mt: 2, flexWrap: "wrap" }}>
            {Object.entries(TYPE_WEIGHT_LABEL).map(([type, label]) => (
              <Box key={type} sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                <Box
                  sx={{
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    background:
                      type === "Placement" ? "#51cf66" : type === "Result" ? "#5c7cfa" : "#ffd43b",
                  }}
                />
                <Typography variant="caption" color="text.disabled">
                  {type}: {label}
                </Typography>
              </Box>
            ))}
          </Box>
        </Paper>

        {/* Error */}
        {error && (
          <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {/* Priority list */}
        <Stack spacing={1.5}>
          {loading
            ? Array.from({ length: n }).map((_, i) => (
                <Skeleton
                  key={i}
                  variant="rounded"
                  height={76}
                  sx={{ bgcolor: "rgba(255,255,255,0.04)" }}
                />
              ))
            : topN.length === 0
            ? (
              <Box sx={{ textAlign: "center", py: 8, color: "text.secondary" }}>
                <Typography variant="h6">No notifications to rank</Typography>
              </Box>
            )
            : topN.map((notif, i) => (
                <NotificationCard
                  key={notif.id}
                  notification={notif}
                  rank={i + 1}
                  onRead={handleRead}
                />
              ))}
        </Stack>
      </Container>
    </Box>
  );
}
