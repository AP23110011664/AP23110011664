/**
 * Logging Middleware
 * ------------------
 * Structured logger for the campus notifications frontend.
 * Replaces all console.log / console.error usage throughout the app.
 * Each log entry is a structured JSON object with level, timestamp,
 * context, and message — consistent with the backend logging middleware.
 */

type LogLevel = "DEBUG" | "INFO" | "WARN" | "ERROR";

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  context: string;
  message: string;
  data?: unknown;
}

const LOG_LEVEL_PRIORITY: Record<LogLevel, number> = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3,
};

const currentLevel: LogLevel =
  (process.env.NEXT_PUBLIC_LOG_LEVEL as LogLevel) ?? "INFO";

function shouldLog(level: LogLevel): boolean {
  return LOG_LEVEL_PRIORITY[level] >= LOG_LEVEL_PRIORITY[currentLevel];
}

function formatEntry(entry: LogEntry): string {
  return JSON.stringify(entry);
}

function emit(entry: LogEntry): void {
  if (!shouldLog(entry.level)) return;
  const line = formatEntry(entry);
  switch (entry.level) {
    case "ERROR":
      // eslint-disable-next-line no-console
      console.error(line);
      break;
    case "WARN":
      // eslint-disable-next-line no-console
      console.warn(line);
      break;
    default:
      // eslint-disable-next-line no-console
      console.info(line);
  }
}

export function getLogger(context: string) {
  const base = (level: LogLevel) =>
    (message: string, data?: unknown): void => {
      emit({
        timestamp: new Date().toISOString(),
        level,
        context,
        message,
        ...(data !== undefined ? { data } : {}),
      });
    };

  return {
    debug: base("DEBUG"),
    info: base("INFO"),
    warn: base("WARN"),
    error: base("ERROR"),
  };
}
